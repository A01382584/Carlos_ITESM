#include <fstream>
#include <string>
#include <list>
#include <algorithm>
#include <iostream>
#include "tabla_hash.h"

using namespace std;

int main() {
    
    Tabla HashT;
    int opcion_menu;
    int key;
    string value;

    HashT.insert(2584, "Carlos");
    HashT.insert(4501, "Lorena");
    HashT.insert(2310, "Ramiro");
    HashT.insert(3345, "Xochil");

    cout << endl;
    cout << "Act 5.1 - Implementación de operaciones sobre conjuntos" << endl;
    cout << "Seleccione lo que desee hacer:" << endl;
    cout << "(Teclee el numero de la opcion en el Listado y presione enter)." << endl;


    do{

        cout << endl;
        cout << "1. Imprimir la tabla." << endl;
        cout << "2. Agregar un nuevo dato." << endl;
        cout << "0. Salir del programa." << endl;
        cout << endl;

        cin >> opcion_menu;

        switch(opcion_menu){
            case 1:
            cout << "1. Imprimir la tabla." << endl;
            cout << endl;

            //posible implementacion de la bool...

            HashT.printTable();

            break;

            case 2:
            cout << "2. Agregar un nuevo dato." << endl;
            cout << endl;

            cout << "Llave del registro: " << endl;
            cout << endl;
            cin >> key;

            cout << "Valor del registro: " << endl;
            cout << endl;
            cin >> value;

            HashT.insert(key, value);

            break;

            case 0:
            cout << "0. Salir del programa." << endl;
            cout << endl;
            break;

            default:
            cout << "Comando no permitido." << endl;
            cout << endl;
        };

    } while (opcion_menu != 0);

    return 0;
}
