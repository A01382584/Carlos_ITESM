#ifndef TABLA_HASH_H
#define TABLA_HASH_H
#include "registro_hash.h"
#include <vector>
#include <list>
#include <cstring>

#include <iostream>

using namespace std;

class Tabla {
    private:
    static const int gruposHash = 100;    
    list<pair<int, string>> tabla[gruposHash];
    
    public:
    bool vacia() const;
    int cuadratic(int llave);
    int cuadratic2(int llave);
    void insert(int llave, string value);
    string search(int llave);
    void printTable();
};

#endif