#include "registro_hash.h"
#include <vector>
#include "tabla_hash.h"
#include "list"
#include <string>

#include <iostream>

using namespace std;

bool Tabla::vacia() const{
    int suma{};
    for (int i{}; i < gruposHash; i++){
        suma += tabla[i].size();
    }

    if (!suma) {
        return true;
    }

    return false;

};

int Tabla::cuadratic(int llave){
    //hash function

    int cuadrado  = llave * llave;

    string cuadradost = to_string(cuadrado);
    int length = cuadradost.length();
    int medio = length/2;

    string medios = cuadradost.substr((medio - 1), 2);

    int resultado = std::stoi(medios);

    return resultado;


};

int Tabla::cuadratic2(int llave){
    //hash function
    return llave % gruposHash;

};

void Tabla::insert(int llave, string value){
    int valorHash = cuadratic(llave);
    cout << "Hash " << valorHash << endl;
    auto& cache = tabla[valorHash];
    auto itera = begin(cache);
    bool existeLlave = false;

    for(; itera != end(cache); itera++){
        if(itera->first == llave){

            existeLlave = true;
            itera->second = value;
            break;

        }
        
    }

    if (!existeLlave){
        cache.emplace_back(llave, value);
    }

};

// string Tabla::search(int llave){

// };

void Tabla::printTable(){
    for (int i{}; i < gruposHash; i++) {
        if (tabla[i].size()==0) continue;

        auto itera = tabla[i].begin();
        for(; itera != tabla[i].end(); itera++){
            cout << "Llave: " << itera->first << "  " << "Valor: " << itera->second << endl;
        }
    }

};