#include <iostream>
#include <fstream>
#include "registro_hash.h"

using namespace std;

void Hash::hash_insert(int llave, string value){
    this->llave = llave;
    this->value = value;
};