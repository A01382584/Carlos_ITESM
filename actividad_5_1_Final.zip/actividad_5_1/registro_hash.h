#ifndef REGISTRO_HASH_H
#define REGISTRO_HASH_H

#include <iostream>

using namespace std;

class Hash {
    public:
    void hash_insert(int llave, string value);
    
    public:
    int llave;
    string value;
    
};

#endif