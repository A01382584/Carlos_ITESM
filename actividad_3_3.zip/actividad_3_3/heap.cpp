#include "heap.h"
#include <iostream>
#include <vector>

using namespace std;

Heap::Heap(){

    vector<int> v = {};

};

Heap::~Heap(){

};


void Heap::push(int data){

    v.push_back(data);
    int length = v.size();
    int dato = length - 1;
    int i2 = (length - 1) / 2;

    if(v.size() == 0){
        v.push_back(data);
    }

    else if(v.size() == 1){
        v.push_back(data);
        if(data < v[0]){
            swap(v[0], v[1]);
        }
    }

    else if(v.size() == 2){
        v.push_back(data);
        if(data > v[0]){
            swap(v[0], v[2]);
        }
    }

    else{
        while (i2 >= 0){
            if(v[dato] <= (v[i2])){
                break;
            }
            else if(v[dato] > v[i2]){
                swap(v[i2], v[dato]);
                dato = i2;
                i2 = i2/2;
            }
        }        
    }

};

void Heap::pop(){

    int m = 0;
    int n = 1;
    bool insert = false;

    if(v.size() == 0){
        cout << "No hay datos en la fila priorizada" << endl;
    }
    
    if(v.size() == 1){
        v.pop_back();
    }

    else{
        swap(v[0], v[v.size() - 1]);
        v.pop_back();
        while (insert != true){
            if(v[m] < v[n] && v[m] < v[n+1]){
                insert = true;
            }

            else if(v[m] > v[n]){
                swap(v[m], v[n]);
                m = n;
                n = 2*m;
            }

            else if(v[m] > v[n+1]){
                swap(v[m], v[n+1]);
                m = n+1;
                n = 2*m;
            }

            else if(m > (v.size()-1)){
                insert = true;
            }
        }
    }

};

void Heap::top(){
    if(v.size() == 0){
        cout << "No hay datos en la fila priorizada" << endl;
    }

    else if(v.size() >= 1){
    cout << "El dato con mayor prioridad es: " << v[0] << endl;
    }

};

bool Heap::empty(){
    cout << "Status de la fila priorizada: (Null?)" << endl;
    bool status = false;
    if(v.size() != 0){
        status = true;
        cout << status << endl;
    }
    else if(v.size() == 0){
        status = false;
        cout << status << endl;
    }
    return status;

};

void Heap::size(){
    cout << "Datos en la fila priorizada: " << v.size() << endl;
};

void Heap::print(){
    cout << "Datos en el Heap: " << endl;

    if(v.size() == 0){
        cout << "No hay datos en la fila priorizada" << endl;
    }
    
    for(int i = 0; i < v.size(); i++){
        cout << v[i] << " ";
    }
    cout << endl;
};