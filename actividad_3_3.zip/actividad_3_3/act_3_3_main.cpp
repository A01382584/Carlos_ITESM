#include <iostream>
#include "heap.h"
#include <random>
#include <vector>
#include <algorithm>

using namespace std;

int main(){

    int n = 20;
    int m; 
    Heap registros;

    random_device rndd;
    mt19937 gen(rndd());
    uniform_int_distribution<> distr(1, 100);
    
    int opcion_menu;

    cout << endl;
    cout << "Act 3.1 - Operaciones avanzadas en un BST." << endl;
    cout << "Seleccione lo que desee hacer:" << endl;
    cout << "(Teclee el numero de la opcion en el Listado y presione enter)." << endl;

    do{

        cout << endl;
        cout << "1. Crear el Heap Dummy." << endl;
        cout << "2. Agregar un nodo." << endl;
        cout << "3. Imprimir el Heap." << endl;
        cout << "4. Consulta  el valor del dato que esta con mayor prioridad." << endl;
        cout << "5. Consulta si esta o no vacío un Heap." << endl;
        cout << "6. Consulta el tamaño del Heap." << endl;
        cout << "7. Eliminar un nodo." << endl;
        cout << "0. Salir del programa." << endl;
        cout << endl;

        cin >> opcion_menu;

        switch(opcion_menu){
            case 1:
            cout << "1. Crear el Heap Dummy." << endl;

            for(int i = 0; i < n; i++){
                m = distr(gen);
                registros.push(m);
                cout << m << " ";
            }

            break;

            case 2:
            cout << "2. Agregar un nodo." << endl;
            cout << endl;

            cout << "Ingrese el nodo que quiere insertar: " << endl;
            cin >> m;
            cout << endl;

            registros.push(m);
            cout << endl;

            break;

            case 3:
            cout << "3. Imprimir el Heap." << endl;
            cout << endl;

            registros.print();
            cout << endl;

            break;

            case 4:
            cout << "4. Consulta el valor del dato que esta con mayor prioridad." << endl;
            cout << endl;

            registros.top();
            cout << endl;

            break;

            case 5:
            int nodoi;
            cout << "5. Consulta si esta o no vacío un Heap." << endl;
            cout << endl;

            registros.empty();
            cout << endl;

            break;

            case 6:
            int nodo;
            cout << "6. Consulta el tamaño del Heap." << endl;
            cout << endl;

            registros.size();
            cout << endl;

            break;

            case 7:
            cout << "7. Eliminar un nodo." << endl;
            cout << endl;

            registros.pop();
            cout << endl;

            break;

            case 0:
            cout << "0. Salir del programa." << endl;
            cout << endl;
            break;

            default:
            cout << "Comando no permitido." << endl;
            cout << endl;
        };

    } while (opcion_menu != 0);

    return 0;

};
