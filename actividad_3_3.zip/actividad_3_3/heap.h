#ifndef HEAP_H
#define HEAP_H
#include <iostream>
#include <vector>

using namespace std;

class Heap{

    private:
    vector<int> v;


    public:

    Heap();
    ~Heap();

    void push(int data);
    void pop();
    void top();
    bool empty();
    void size();
    void print();

};

#endif