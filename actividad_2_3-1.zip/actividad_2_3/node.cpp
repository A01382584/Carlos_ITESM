#include <iostream>
#include "node.h"
#include "registro.h"

using namespace std;

Node::Node() {
    prev = nullptr;
    next = nullptr;
    registro;
};

Node::Node(Registro registro, Node* prev, Node* next) {
    this->registro = registro;
    this->prev = prev;
    this->next = next;
};