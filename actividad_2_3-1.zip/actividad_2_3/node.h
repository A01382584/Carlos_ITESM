#ifndef NODE_H
#define NODE_H

#include <iostream>
#include "registro.h"

using namespace std;

class Node {
    public:
    Node();
    Node(Registro registro, Node* prev, Node* next);
    
    public:
    
    Registro registro;
    Node* prev;
    Node* next;
};

#endif