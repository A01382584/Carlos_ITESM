#ifndef DOUBLYLINKED_H_
#define DOUBLYLINKED_H_
#include <iostream>
#include "node.h"



using namespace std;

class DoublyLinkedList {
private:
    Node* head; // Puntero al inicio de la lista
    Node* tail; // Puntero al final de la lista

public:
    DoublyLinkedList();

    Node* createNode(Registro registro);

    void insert(Registro registro);

    Node* search(Registro registro);

    void update(Registro registroviejo, Registro registronuevo);

    void remove(Registro registro);

    void printList();

    void sort(bool movimiento);

    Node* begin() const;

    Node* end() const;

};

#endif