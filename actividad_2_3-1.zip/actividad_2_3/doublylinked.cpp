#include <iostream>
#include <fstream>
#include "node.h"
#include "doublylinked.h"
#include "registro.h"

using namespace std;

DoublyLinkedList::DoublyLinkedList(){
    
    head  = nullptr;
    tail = nullptr;
    string data = "";
}

// Función para crear un nuevo nodo
Node* DoublyLinkedList::createNode(Registro registro) {
    Node* newNode = new Node;
    newNode->registro = registro;
    newNode->prev = nullptr;
    newNode->next = nullptr;
    return newNode;
};

// Operación de creación (Create)
void DoublyLinkedList::insert(Registro registro) {
    Node* newNode = createNode(registro);
    if (head == nullptr) {
        head = newNode;
        tail = newNode;
    }
    else {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
};

// Operación de lectura (Read)
Node* DoublyLinkedList::search(Registro registro) {
    Node* temp = head;
    while (temp != nullptr) {
        if (temp->registro == registro) {
            return temp;
        }
        temp = temp->next;
    }
    return nullptr;
};

// Operación de actualización (Update)
void DoublyLinkedList::update(Registro registroviejo, Registro registronuevo) {
    Node* nodeToUpdate = search(registroviejo);
    if (nodeToUpdate != nullptr) {
        nodeToUpdate->registro = registronuevo;
        cout << "Elemento actualizado: " << registroviejo << endl;
    }
    else {
        cout << "Elemento no encontrado: " << registroviejo << endl;
    }
};

// Operación de eliminación (Delete)
void DoublyLinkedList::remove(Registro registro) {
    Node* nodeToRemove = search(registro);
    if (nodeToRemove != nullptr) {
        if (nodeToRemove == head && nodeToRemove == tail) {
            head = nullptr;
            tail = nullptr;
        }
        else if (nodeToRemove == head) {
            head = head->next;
            head->prev = nullptr;
        }
        else if (nodeToRemove == tail) {
            tail = tail->prev;
            tail->next = nullptr;
        }
        else {
            nodeToRemove->prev->next = nodeToRemove->next;
            nodeToRemove->next->prev = nodeToRemove->prev;
        }
        delete nodeToRemove;
        cout << "Elemento eliminado: " << endl;
    }
    else {
        cout << "Elemento no encontrado: " << endl;
    }
};

// Función para imprimir la lista
void DoublyLinkedList::printList() {
    Node* temp = head;
    while (temp != nullptr) {
        cout << temp->registro << endl;
        temp = temp->next;
    }
    cout << endl;
};

void DoublyLinkedList::sort(bool orden) {
    
    bool movimiento = orden; //ascendente o descendente

    Node* primero = head;
    Node* ultimo = nullptr;
  
    if (head == nullptr)
        return;
  
    do {
        movimiento = false;
        primero = head;
  
        while (primero->next != ultimo) {
            if (primero->registro.ip > primero->next->registro.ip) {
                swap(primero->registro.ip, primero->next->registro.ip);
                movimiento = true;
            }
            primero = primero->next;
        }
        ultimo = primero;
    } while (movimiento);
    cout << endl;
};

Node* DoublyLinkedList::begin() const {
    return head;
};

Node* DoublyLinkedList::end() const {
    return tail;
};

// const es para hacer gets que aseguren que modifiques el valor de nada. solo lo jalas