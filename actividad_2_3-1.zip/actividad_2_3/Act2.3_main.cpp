#include <fstream>
#include <string>
#include <list>
#include <algorithm>
#include <iostream>
#include "node.h"
#include "doublylinked.h"
#include "registro.h"

using namespace std;

int main() {
    
    DoublyLinkedList registros;
    Registro log;
    ifstream archivo("bitacora.txt");
    string linea;
    bool Direccion;
    int opcion_menu;
    string ip_inicio;
    string ip_fin;
    ofstream archivo_ordenado("bitacora_ordenada.txt");
    ofstream archivo_filtrado("bitacora_filtrada.txt");

    cout << endl;
    cout << "Act 2.3 - Actividad Integral estructura de datos lineales (Evidencia Competencia)." << endl;
    cout << "Seleccione lo que desee hacer:" << endl;
    cout << "(Teclee el numero de la opcion en el Listado y presione enter)." << endl;

    do{

        cout << endl;
        cout << "1. Crear la lista doblemente ligada inicial." << endl;
        cout << "2. Formatear de manera ascendente o descendente la lista doblemente ligada." << endl;
        cout << "3. Crear la vista ordenada en el archivo txt." << endl;
        cout << "4. Crear la vista filtrada en el archivo txt." << endl;
        cout << "0. Salir del programa." << endl;
        cout << endl;

        cin >> opcion_menu;

        switch(opcion_menu){
            case 1:
            cout << "1. Crear la lista doblemente ligada inicial." << endl;
            cout << endl;

            if (!archivo) {
                cout << "No se pudo abrir el archivo." << endl;
            }

            else{
                while (getline(archivo, linea)){
                        size_t pos0 = linea.find_first_of(" ");
                        size_t pos1 = linea.find_first_of(" ", pos0+1);
                        size_t pos2 = linea.find_first_of(" ", pos1+1);
                        size_t pos3 = linea.find_first_of(" ", pos2+1);
                        log.mes = linea.substr(0, 3);
                        log.dia = linea.substr(pos0+1, (pos1 + 1)- (pos0+1));
                        log.hora = linea.substr(pos1+1, 8);
                        log.ip = linea.substr(pos2+1, (pos3 + 1)- (pos2+1));
                        log.solicitud = linea.substr(pos3+1);
                        registros.insert(log);
                }

                cout << "Se ha creado la lista a partir del archivo de texto exitosamente." << endl;

            }

            break;

            case 2:
            cout << "2. Formatear de manera ascendente o descendente la lista doblemente ligada." << endl;
            cout << endl;

            cout << "Ingrese 0 para Descendente o 1 para Ascendente: " << endl;
            cin >> Direccion;
            registros.sort(Direccion);

            break;

            case 3:
            cout << "3. Crear la vista ordenada en el archivo txt." << endl;
            cout << endl;

            for (Node* current = registros.begin(); current != registros.end(); current = current->next){
                Registro input = current->registro;
                archivo_ordenado << input.ip << " [" << input.mes << ":"  << input.dia << ":"<< input.hora << "] \"" << input.solicitud << "\"" << endl;
            }
            archivo_ordenado.close();

            break;

            case 4:
            cout << "4. Crear la vista filtrada en el archivo txt." << endl;
            cout << endl;

            cout << "Ingrese la IP de inicio de la búsqueda: " << endl;
            cin >> ip_inicio;
            cout << "Ingrese la IP de fin de la búsqueda: " << endl;
            cin >> ip_fin;

            for (Node* current = registros.begin(); current != registros.end(); current = current->next){
                Registro input = current->registro;
                if (input.ip >= ip_inicio && input.ip <= ip_fin){
                    archivo_filtrado << input.ip << " [" << input.mes << ":"  << input.dia << ":"<< input.hora << "] \"" << input.solicitud << "\"" << endl;
                }
            }
            archivo_filtrado.close();

            break;

            case 0:
            cout << "0. Salir del programa." << endl;
            cout << endl;
            break;

            default:
            cout << "Comando no permitido." << endl;
            cout << endl;
        };

    } while (opcion_menu != 0);

    return 0;
}
