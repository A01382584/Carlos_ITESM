#ifndef REGISTRO_H
#define REGISTRO_H

#include <iostream>
using namespace std;

struct Registro {
    
    string ip;
    string mes;
    string dia;
    string hora;
    string solicitud;

    friend ostream& operator<<(ostream& os, const Registro& registro) {
    os << registro.mes << " " << registro.dia << " " << registro.hora << " " << registro.ip << registro.solicitud << " ";
    return os;
    }

    bool operator==(const Registro& registro) const {
        return ip == registro.ip && mes == registro.mes && hora == registro.hora && solicitud == registro.solicitud && dia == registro.dia;
    }

    bool compararIP(const Registro& a, const Registro& b) {
    return a.ip < b.ip;
    }

};

#endif