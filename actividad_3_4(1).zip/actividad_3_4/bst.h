#ifndef BST_H
#define BST_H
#include "node.h"
#include <iostream>
#include <fstream>
#include <sstream>


using namespace std;

class BinaryT{

    public:
    BinaryT();

    //Pseudo CRUD
    Node* createINode(Registro registro);
    void createNode(Registro registro);
    Node* searchNode(Registro registro);

    //ACT 3.1
    //Visits
    void visitBST(Node *Nodito, ofstream& archivo_filtrado);
    void visitBSTIP(Node *Nodito, ofstream& archivo_filtrado);

    //Print visits desde root
    void pvisitBST(ofstream& archivo_filtrado);
    void pvisitBSTIP(ofstream& archivo_filtrado);

    public:
    Node *root = nullptr;
    ofstream archivo_filtrado;

};

#endif