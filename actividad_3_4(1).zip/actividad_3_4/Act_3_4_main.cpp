#include <fstream>
#include <string>
#include <list>
#include <algorithm>
#include <iostream>
#include "node.h"
#include "bst.h"
#include "registro.h"
#include <vector>
#include <sstream>
#include <map>

using namespace std;

int main() {
    
    BinaryT registros;
    Registro log;
    ifstream archivo("bitacora.txt");
    string linea;
    bool Direccion;
    int opcion_menu;
    string ip_inicio;
    string ip_fin;
    ofstream archivo_ordenado("bitacora_ordenada.txt");
    ofstream archivo_filtrado("bitacora_filtrada.txt");

    ifstream archivo_ordenado_tops("bitacora_ordenada.txt");
    map<string, int> ips;
    string line;
    int contador = 1;
    vector<pair<string, int>> ips_sort;
    auto sort_ips = [](pair<string, int> const& a, pair<string, int> const& b) {
    return a.second > b.second;
    };
    bool status;


    cout << endl;
    cout << "Act 3.4 - Actividad Integral de BST (Evidencia Competencia)." << endl;
    cout << "Seleccione lo que desee hacer:" << endl;
    cout << "(Teclee el numero de la opcion en el Listado y presione enter)." << endl;

    do{

        cout << endl;
        cout << "1. Crear el BST (Carga de datos)." << endl;
        cout << "2. Imprimir en txt todas las ips." << endl;
        cout << "3. Top 5 IPs." << endl;
        cout << "0. Salir del programa." << endl;
        cout << endl;

        cin >> opcion_menu;

        switch(opcion_menu){
            case 1:
            cout << "1. Crear el BST (Carga de datos)." << endl;
            cout << endl;

            if (!archivo) {
                cout << "No se pudo abrir el archivo." << endl;
            }

            else{
                while (getline(archivo, linea)){
                        size_t pos0 = linea.find_first_of(" ");
                        size_t pos1 = linea.find_first_of(" ", pos0+2);
                        size_t pos2 = linea.find_first_of(" ", pos1+1);
                        size_t pos3 = linea.find_first_of(" ", pos2+1);
                        log.mes = linea.substr(0, 3);
                        log.dia = linea.substr(pos0+1, (pos1 + 1)- (pos0+1));
                        log.hora = linea.substr(pos1+1, (pos2 + 1)- (pos1+1));
                        log.ip = linea.substr(pos2+1, (pos3 + 1)- (pos2+1));
                        log.solicitud = linea.substr(pos3+1);
                        registros.createNode(log);
                }

                cout << "Se ha creado el BST a partir del archivo de texto exitosamente." << endl;

            }

            break;

            case 2:
            cout << "2. Imprimir en txt todas las ips." << endl;
            cout << endl;

            registros.pvisitBST(archivo_filtrado);
            archivo_filtrado.close();

            break;

            case 3:
            cout << "3. Top 5 IPs." << endl;
            cout << endl;

            registros.pvisitBSTIP(archivo_ordenado);
            archivo_ordenado.close();

            while (getline(archivo_ordenado_tops, line)) {
                istringstream insstr(line);
                string ip;
                getline(insstr, ip, ':');
                if (ip.length() < 3) {
                    continue;
                }

                else{
                    ips[ip]++;
                    for (auto& p : ips_sort) {
                    if (p.first == ip) {
                        p.second = ips[ip];
                        status = true;
                        break;
                    }
                    else{
                        status = false;
                    }
                    }
                    if (status == false){
                        ips_sort.push_back(make_pair(ip, ips[ip]));
                    }

                }
            }
            
            archivo_ordenado_tops.close();

            sort(ips_sort.begin(), ips_sort.end(), sort_ips);

            cout << "Top 5 IPS:" << endl;
            for (int i = 0; i < 5 && i < ips_sort.size(); i++) {
            cout << i+1 << ". " << ips_sort[i].first << ": " << ips_sort[i].second << endl;
            }

            break;

            case 0:
            cout << "0. Salir del programa." << endl;
            cout << endl;

            break;

            default:
            cout << "Comando no permitido." << endl;
            cout << endl;

        };

    } while (opcion_menu != 0);

    return 0;


}
