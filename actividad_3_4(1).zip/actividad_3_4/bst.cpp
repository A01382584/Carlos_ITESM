#include "bst.h"
#include <iostream>
#include <queue>

using namespace std;

BinaryT::BinaryT(){
    root = nullptr;
};

Node* BinaryT::createINode(Registro registro){
    Node* INode = new Node;
    INode->registro = registro;
    INode->left = nullptr;
    INode->right = nullptr;
    return INode;
};

void BinaryT::createNode(Registro registro) {
    
    Node* newNode = createINode(registro);
    Node *temporary, *troot;

    if (root == nullptr){
        root = newNode;
    }

    else {

        temporary = root;
        while (temporary != nullptr){
            troot = temporary;
            if (registro.ip < temporary->registro.ip){
                temporary = temporary->left;
            }
            else{
                temporary = temporary->right;
            }
        }

        if (registro.ip < troot->registro.ip){
            troot->left = newNode;
        }
        else{
            troot->right = newNode;
        }

    }

};


Node* BinaryT::searchNode(Registro registro){
    Node* temporary = root;
    Node* result;

    while (temporary != nullptr){
        result = temporary;
        if(registro.ip < temporary->registro.ip){
            temporary = temporary->left;      
        }

        else if (registro.ip > temporary->registro.ip){     
            temporary = temporary->right;
        }

        else{
            return result;
        }
    }

    if (temporary == nullptr){
        cout << "No existe en el BST." << endl;
    }

    return result;
};

void BinaryT::visitBST(Node *Nodito, ofstream& archivo_filtrado){
    if(Nodito != nullptr){
        visitBST(Nodito->left, archivo_filtrado);
        Registro input = Nodito->registro;
        archivo_filtrado << input.ip << " [" << input.mes << ":"  << input.dia << ":"<< input.hora << "] \"" << input.solicitud << "\"" << endl;
        visitBST(Nodito->right, archivo_filtrado);
    }
};

void BinaryT::pvisitBST(ofstream& archivo_filtrado){
    visitBST(root, archivo_filtrado);
    cout << endl;
};

void BinaryT::visitBSTIP(Node *Nodito, ofstream& archivo_filtrado){
    if(Nodito != nullptr){
        visitBSTIP(Nodito->left, archivo_filtrado);
        Registro input = Nodito->registro;
        archivo_filtrado << input.ip << endl;
        visitBSTIP(Nodito->right, archivo_filtrado);
    }
};

void BinaryT::pvisitBSTIP(ofstream& archivo_filtrado){
    visitBSTIP(root, archivo_filtrado);
    cout << endl;
};