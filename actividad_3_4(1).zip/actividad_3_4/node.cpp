#include <iostream>
#include "node.h"
#include "registro.h"

using namespace std;

Node::Node() {
    left = nullptr;
    right = nullptr;
    registro;
};

Node::Node(Registro registro, Node* prev, Node* next) {
    this->registro = registro;
    this->left = left;
    this->right = right;
};