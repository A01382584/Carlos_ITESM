#include <iostream>
#include <cmath>
#include <chrono>
#include <string>
#include <vector>

using namespace std;
using namespace std::chrono;

//Problema 1
int suma_fibonacci_recursiva(int n){
    if (n <= 1){
        return n;
    }
    else {
        return suma_fibonacci_recursiva(n-1) + suma_fibonacci_recursiva(n-2);
    }
}

int suma_fibonacci_iterativa(int n){
    int a = 0, b = 1, c;

    for (int i = 1; i <= n; i++) {
        c = a + b;
        a = b;
        b = c;
    }
  return c;
}

//Problema 2
int suma_arreglo_recursiva(int arr[], int size){
    if (size == 0) {
        return 0;
    } else {
        return arr[size-1] + suma_arreglo_recursiva(arr, size-1);
    }
}

int suma_arreglo_iterativa(int arr[], int size){
    int sum = 0;
    for (int i = 0; i < size; i++) {
        sum += arr[i];
    }
    return sum;
}

//Problema 3
bool is_palindromo_recursiva(string str, int izq, int derecha){
    if (izq >= derecha) {
        return true;
    }

    if (str[izq] != str[derecha]) {
        return false;
    } else {
        return is_palindromo_recursiva(str, izq+1, derecha-1);
    }
}

bool suma_palindromo_iterativa(string str){
    int izq = 0;
    int derecha = str.length()-1;

    while (izq < derecha) {
        if (str[izq] != str[derecha]) {
            return false;
        }
        izq++;
        derecha--;
    }
    return true;
}

int max_iterative(const vector<int>& arr) {
    int max_val = arr[0];
    for (int i = 1; i < arr.size(); i++) {
        if (arr[i] > max_val) {
            max_val = arr[i];
        }
    }
    return max_val;
}

bool isAscendingIterative(const vector<int>& arr) {
    for (int i = 1; i < arr.size(); i++) {
        if (arr[i] < arr[i - 1]) {
            return false;
        }
    }
    return true;
}

bool isAscendingRecursive(const vector<int>& arr, int n) {
    if (n == 1) {
        return true;
    }
    if (arr[n - 1] < arr[n - 2]) {
        return false;
    }
    return isAscendingRecursive(arr, n - 1);
}

int suma_digitos_recursiva(int n){
    if (n < 10){
        return n;
    }
    else {
        return (n % 10) + suma_digitos_recursiva(n / 10);
    }
}

int suma_digitos_iterativa(int n) {
    int suma = 0;
    while (n > 0) {
        suma += n % 10;
        n /= 10;
    }
    return suma;
}

bool orden_descentente_recursivo(int arr[], int size){
    if (size == 1){
        return true;
    }
    if (arr[size - 1] > arr[size - 2]){
        return false;
    }
    return orden_descentente_recursivo(arr, size - 1);
}

bool orden_descentente_iterativo(int arr[], int size){
    for (int i = 1; i < size; i++){
        if (arr[i] > arr[i - 1]){
            return false;
        }
    }
    return true;
}

int contar_char_recursivo(string str, char c) {
    if (str.length() == 0) {
        return 0;
    }
    if (str[0] == c) {
        return 1 + contar_char_recursivo(str.substr(1), c);
    } else {
        return contar_char_recursivo(str.substr(1), c);
    }
}

int contar_char_iterativo(string str, char c) {
    int contador = 0;
    for (char ch : str) {
        if (ch == c) {
            contador++;
        }
    }
    return contador;
}

int sumatoria_iterativa(int n) {
    int resultado = 0;
    for (int i = 1; i <= n; i++) {
        resultado += i;
    }
    return resultado;
}

int sumatoria_recursiva(int n) {
    if (n == 1) {
        return 1;
    }
    return n + sumatoria_recursiva(n - 1);
}

int main() {
  int n;
  int arr[] = {1,2,3,4,5};
  int size = sizeof(arr) / sizeof(arr[0]);
  string str;
  char c;

  vector<int> arr1 = {5, 8, 2, 11, 7, 1, 9, 4};
  vector<int> arr2 = {1, 2, 3, 4, 5};
  vector<int> arr3 = {10, 9, 8, 7, 6};

  vector<int> arr4{ 1, 2, 3, 4, 5 };
  vector<int> arr5{ 1, 3, 2, 4, 5 };
  vector<int> arr6{ 5, 4, 3, 2, 1 };
  
  //Problema 1, suma de dígitos de un número
  cout << ""<< "\n";
  cout << "Problema 1"<< "\n";
  cout << "Introduce el número para suma de Fibonacci: ";
  cin >> n;
  //Forma recursiva
  auto start_timer = chrono::high_resolution_clock::now();
  cout << "Suma de Fibonacci recursiva: " << suma_fibonacci_recursiva(n) << "\n";
  auto end_timer = chrono::high_resolution_clock::now();
  auto run_time = chrono::duration_cast<chrono::nanoseconds> (end_timer - start_timer); 
  cout << "Tiempo de ejecución: " << run_time.count() << " nanosegundos\n";
  
  //Forma iterativa
  cout << ""<< "\n";
  cout << "Problema 1.2"<< "\n";
  cout << "Introduce el número para suma de Fibonacci: ";
  start_timer = chrono::high_resolution_clock::now();
  cin >> n;
  cout << "Suma de Fibonacci iterativa: " << suma_fibonacci_iterativa(n) << "\n";
  end_timer = chrono::high_resolution_clock::now();
  run_time = chrono::duration_cast<chrono::nanoseconds> (end_timer - start_timer); 
  cout << "Tiempo de ejecución: " << run_time.count() << " nanosegundos\n";

  //Problema 2, suma de numeros en arreglo
  //Forma recursiva
  cout << ""<< "\n";
  cout << "Problema 2"<< "\n";
  cout << "Suma de este array recursiva: {1, 2, 3, 4, 5}" << "\n";
  start_timer = chrono::high_resolution_clock::now();
  cout << suma_arreglo_recursiva(arr, size) << "\n";
  end_timer = chrono::high_resolution_clock::now();
  run_time = chrono::duration_cast<chrono::nanoseconds> (end_timer - start_timer); 
  cout << "Tiempo de ejecución: " << run_time.count() << " nanosegundos\n";

  //Forma iterativa
  cout << ""<< "\n";
  cout << "Problema 2.2"<< "\n";
  cout << "Suma de este array iterativa: {1, 2, 3, 4, 5}" << "\n";
  start_timer = chrono::high_resolution_clock::now();
  cout << suma_arreglo_iterativa(arr, size) << "\n";
  end_timer = chrono::high_resolution_clock::now();
  run_time = chrono::duration_cast<chrono::nanoseconds> (end_timer - start_timer); 
  cout << "Tiempo de ejecución: " << run_time.count() << " nanosegundos\n";

  //Problema 3, suma de numeros en arreglo
  //Forma recursiva
  cout << ""<< "\n";
  cout << "Problema 3"<< "\n";
  cout << "Escribe una palabra: ";
  cin >> str;
  cout << "Es o no es palindromo?" << "\n";
  start_timer = chrono::high_resolution_clock::now();
  bool palindrome = is_palindromo_recursiva(str, 0, str.length()-1);
  if (palindrome) {
    cout << str << " Si es un palindrome." << "\n";
} else {
    cout << str << " No es un palindrome" << "\n";
}
  end_timer = chrono::high_resolution_clock::now();
  run_time = chrono::duration_cast<chrono::nanoseconds> (end_timer - start_timer); 
  cout << "Tiempo de ejecución: " << run_time.count() << " nanosegundos\n";

  //Forma iterativa
  cout << ""<< "\n";
  cout << "Problema 3.2"<< "\n";
  cout << "Escribe una palabra: ";
  cin >> str;
  cout << "Es o no es palindromo?" << "\n";
  start_timer = chrono::high_resolution_clock::now();
  bool palindrome2 = suma_palindromo_iterativa(str);
  if (palindrome2) {
    cout << str << " Si es un palindrome." << "\n";
} else {
    cout << str << " No es un palindrome" << "\n";
}
  end_timer = chrono::high_resolution_clock::now();
  run_time = chrono::duration_cast<chrono::nanoseconds> (end_timer - start_timer); 
  cout << "Tiempo de ejecución: " << run_time.count() << " nanosegundos\n";

    // Ejecución de la función iterativa con distintos inputs
  cout << ""<< "\n";
  cout << "Problema 4"<< "\n";
  auto start_time = high_resolution_clock::now();
  int max_val1 = max_iterative(arr1);
  auto end_time = high_resolution_clock::now();
  auto time1 = duration_cast<microseconds>(end_time - start_time);
  cout << "Máximo valor del arreglo {5, 8, 2, 11, 7, 1, 9, 4}: " << max_val1 << endl;
  cout << "Tiempo de ejecución del arreglo 1: " << time1.count() << " microsegundos" << endl;
    
  cout << ""<< "\n";
  cout << "Problema 5"<< "\n";
  start_time = high_resolution_clock::now();
  int max_val2 = max_iterative(arr2);
  end_time = high_resolution_clock::now();
  auto time2 = duration_cast<microseconds>(end_time - start_time);
  cout << "Máximo valor del arreglo {1, 2, 3, 4, 5}: " << max_val2 << endl;
  cout << "Tiempo de ejecución del arreglo 2: " << time2.count() << " microsegundos" << endl;
    
  cout << ""<< "\n";
  cout << "Problema 5.2"<< "\n";
  start_time = high_resolution_clock::now();
  int max_val3 = max_iterative(arr3);
  end_time = high_resolution_clock::now();
  auto time3 = duration_cast<microseconds>(end_time - start_time);
  cout << "Máximo valor del arreglo {10, 9, 8, 7, 6}: " << max_val3 << endl;
  cout << "Tiempo de ejecución del arreglo 3: " << time3.count() << " microsegundos" << endl;

  cout << ""<< "\n";
  cout << "Problema 6"<< "\n";
  auto start = high_resolution_clock::now();
  cout << "El arreglo { 1, 2, 3, 4, 5 } es ascendiente?: "<<isAscendingIterative(arr4) << endl; // true
  cout << "El arreglo { 1, 3, 2, 4, 5 } es ascendiente?: " << isAscendingIterative(arr5) << endl; // false
  cout << "El arreglo { 5, 4, 3, 2, 1 } es ascendiente?: " << isAscendingIterative(arr6) << endl; // false
  auto stop = high_resolution_clock::now();
  auto duration = duration_cast<microseconds>(stop - start);
  cout << "Time taken by iterative function: " << duration.count() << " microseconds" << endl;

  cout << ""<< "\n";
  cout << "Problema 6.2"<< "\n";
  start = high_resolution_clock::now();
  cout << "El arreglo { 1, 2, 3, 4, 5 } es ascendiente?: " << isAscendingRecursive(arr4, arr4.size()) << endl; // true
  cout << "El arreglo { 1, 3, 2, 4, 5 } es ascendiente?: " << isAscendingRecursive(arr5, arr5.size()) << endl; // false
  cout << "El arreglo { 5, 4, 3, 2, 1 } es ascendiente?: " << isAscendingRecursive(arr6, arr6.size()) << endl; // false
  stop = high_resolution_clock::now();
  duration = duration_cast<microseconds>(stop - start);
  cout << "Time taken by recursive function: " << duration.count() << " microseconds" << endl;

  //Problema 7, suma de dígitos de un número
  cout << ""<< "\n";
  cout << "Problema 7"<< "\n";
  cout << "Introduce el número para suma de dígitos: ";
  cin >> n;
  //Forma recursiva
  start = high_resolution_clock::now();
  cout << "Suma de dígitos recursiva: " << suma_digitos_recursiva(n) << "\n";
  stop = high_resolution_clock::now();
    duration = duration_cast<microseconds>(stop - start);
    cout << "Time taken by recursive function: " << duration.count() << " microseconds" << endl;
  
  //Forma iterativa
  cout << ""<< "\n";
  cout << "Problema 7.2"<< "\n";
  cout << "Introduce el número para suma de dígitos: ";
  cin >> n;
  start_timer = chrono::high_resolution_clock::now();
  cout << "Suma de dígitos iterativa: " << suma_digitos_iterativa(n) << "\n";
  stop = high_resolution_clock::now();
    duration = duration_cast<microseconds>(stop - start);
    cout << "Time taken by recursive function: " << duration.count() << " microseconds" << endl;

  //Problema 8, determinar si un arreglo está de forma descendente
  cout << ""<< "\n";
  cout << "Problema 8"<< "\n";
  int arri[] = {50,49,48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1};
  int sizei = sizeof(arr) / sizeof(arr[0]);
  //Forma recursiva
  start_timer = chrono::high_resolution_clock::now();
  cout << "El arreglo: {50,49,48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1}" << endl;
  cout << "El arreglo está ordenado descendente (recursivo). 0 no, 1 si: " << (orden_descentente_iterativo(arri, sizei) ) << endl;
  stop = high_resolution_clock::now();
    duration = duration_cast<microseconds>(stop - start);
    cout << "Time taken by recursive function: " << duration.count() << " microseconds" << endl;
  
  cout << ""<< "\n";
  cout << "Problema 8.2"<< "\n";
  cout << "El arreglo: {50,49,48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,32,31,30,29,28,27,26,25,24,23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1}" << endl;
  //Forma iterativa
  start_timer = chrono::high_resolution_clock::now();
  cout << "El arreglo está ordenado descendente (iterativo). 0 no, 1 si: " << (orden_descentente_recursivo(arri, sizei) ) << endl;
  stop = high_resolution_clock::now();
    duration = duration_cast<microseconds>(stop - start);
    cout << "Time taken by recursive function: " << duration.count() << " microseconds" << endl;

  //Problema 9, función que cuenta el número de ocurrencias de un carácter dado en un string
  cout << ""<< "\n";
  cout << "Problema 9"<< "\n";
  cin.ignore();
  cout << "Introduce un string: ";
  getline(cin, str);
  cout << "¿Qué caracter quieres que cuente?: ";
  cin >> c;
  //Forma recursiva
  start_timer = chrono::high_resolution_clock::now();
  cout << "El caracter " << c << " aparece " << contar_char_recursivo(str, c) << " veces (recursivo)" << endl;
  stop = high_resolution_clock::now();
    duration = duration_cast<microseconds>(stop - start);
    cout << "Time taken by recursive function: " << duration.count() << " microseconds" << endl;
  
  //Forma iterativa
  cout << ""<< "\n";
  cout << "Problema 9.2"<< "\n";
  start_timer = chrono::high_resolution_clock::now();
  cout << "El caracter " << c << " aparece " << contar_char_iterativo(str, c) << " veces (iterativo)" << endl;
  stop = high_resolution_clock::now();
    duration = duration_cast<microseconds>(stop - start);
    cout << "Time taken by recursive function: " << duration.count() << " microseconds" << endl;

  //Problema 10, función que calcula la sumatoria de 1 hasta n
  cout << ""<< "\n";
  cout << "Problema 10"<< "\n";
  cout << "Introduce un número para sumar de 1 a n: ";
  cin >> n;
  //Forma recursiva
  start_timer = chrono::high_resolution_clock::now();
  cout << "La sumatoria recursiva de los numeros del 1 al " << n << " es: " << sumatoria_recursiva(n) << endl;
  stop = high_resolution_clock::now();
    duration = duration_cast<microseconds>(stop - start);
    cout << "Time taken by recursive function: " << duration.count() << " microseconds" << endl;
  //Forma iterativa
  cout << ""<< "\n";
  cout << "Problema 10.2"<< "\n";
  start_timer = chrono::high_resolution_clock::now();
  cout << "La sumatoria iterativa de los numeros del 1 al " << n << " es: " << sumatoria_iterativa(n) << endl;
  stop = high_resolution_clock::now();
    duration = duration_cast<microseconds>(stop - start);
    cout << "Time taken by recursive function: " << duration.count() << " microseconds" << endl;
  
}