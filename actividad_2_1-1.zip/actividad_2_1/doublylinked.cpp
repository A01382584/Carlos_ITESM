#include <iostream>
#include "node.h"
#include "doublylinked.h"

using namespace std;

DoublyLinkedList::DoublyLinkedList(){
    
    head  = nullptr;
    tail = nullptr;
    int data = 0;
}

// Función para crear un nuevo nodo
Node* DoublyLinkedList::createNode(int data) {
    Node* newNode = new Node;
    newNode->data = data;
    newNode->prev = nullptr;
    newNode->next = nullptr;
    return newNode;
};

// Operación de creación (Create)
void DoublyLinkedList::insert(int data) {
    Node* newNode = createNode(data);
    if (head == nullptr) {
        head = newNode;
        tail = newNode;
    }
    else {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
    cout << "Elemento insertado: " << data << endl;
};

// Operación de lectura (Read)
Node* DoublyLinkedList::search(int data) {
    Node* temp = head;
    while (temp != nullptr) {
        if (temp->data == data) {
            return temp;
        }
        temp = temp->next;
    }
    return nullptr;
};

// Operación de actualización (Update)
void DoublyLinkedList::update(int oldData, int newData) {
    Node* nodeToUpdate = search(oldData);
    if (nodeToUpdate != nullptr) {
        nodeToUpdate->data = newData;
        cout << "Elemento actualizado: " << oldData << " -> " << newData << endl;
    }
    else {
        cout << "Elemento no encontrado: " << oldData << endl;
    }
};

// Operación de eliminación (Delete)
void DoublyLinkedList::remove(int data) {
    Node* nodeToRemove = search(data);
    if (nodeToRemove != nullptr) {
        if (nodeToRemove == head && nodeToRemove == tail) {
            head = nullptr;
            tail = nullptr;
        }
        else if (nodeToRemove == head) {
            head = head->next;
            head->prev = nullptr;
        }
        else if (nodeToRemove == tail) {
            tail = tail->prev;
            tail->next = nullptr;
        }
        else {
            nodeToRemove->prev->next = nodeToRemove->next;
            nodeToRemove->next->prev = nodeToRemove->prev;
        }
        delete nodeToRemove;
        cout << "Elemento eliminado: " << data << endl;
    }
    else {
        cout << "Elemento no encontrado: " << data << endl;
    }
};

// Función para imprimir la lista
void DoublyLinkedList::printList() {
    Node* temp = head;
    while (temp != nullptr) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
};