#ifndef DOUBLYLINKED_H_
#define DOUBLYLINKED_H_
#include <iostream>
#include "node.h"



using namespace std;

class DoublyLinkedList {
private:
    Node* head; // Puntero al inicio de la lista
    Node* tail; // Puntero al final de la lista

public:
    DoublyLinkedList();

    Node* createNode(int data);

    void insert(int data);

    Node* search(int data);

    void update(int oldData, int newData);

    void remove(int data);

    void printList();
};

#endif