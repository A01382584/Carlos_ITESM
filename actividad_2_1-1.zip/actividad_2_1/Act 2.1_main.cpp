#include <iostream>
#include "node.h"
#include "doublylinked.h"


using namespace std;

int main() {

    DoublyLinkedList list;
    int valor;
    int valoractualizado;

    int opcion_menu;

    cout << endl;
    cout << "Act 2.1 - Implementación de un ADT de estructura de datos lineales." << endl;
    cout << "Seleccione lo que desee hacer:" << endl;
    cout << "(Teclee el numero de la opcion en el Listado y presione enter)." << endl;

    do{

        cout << endl;
        cout << "1. Crear nodo inicial." << endl;
        cout << "2. Crear nuevo nodo." << endl;
        cout << "3. Leer la linked list." << endl;
        cout << "4. Actualizar un nodo." << endl;
        cout << "5. Borrar un nodo." << endl;
        cout << "0. Salir del programa." << endl;
        cout << endl;

        cin >> opcion_menu;

        switch(opcion_menu){
            case 1:
            cout << "1. Crear nodo inicial." << endl;
            cout << "Ingresa el valor del nodo inicial: " << endl;
            cout << endl;
            cin >> valor;
            
            list.insert(valor);
            cout << "Lista creada. " << endl;
            cout << endl;

            break;

            case 2:
            cout << "2. Crear nuevo nodo." << endl;
            cout << "Ingresa el valor del nuevo nodo: " << endl;
            cout << endl;
            cin >> valor;

            list.insert(valor);
            cout << "Nodo agregado. " << endl;
            cout << endl;

            break;

            case 3:
            cout << "3. Leer la linked list." << endl;
            cout << endl;

            list.printList();

            break;

            case 4:
            cout << "4. Actualizar un nodo." << endl;
            cout << "Ingresa el valor a actualizar: " << endl;
            cout << endl;
            cin >> valor;
            cout << "Ingresa el valor actualizado: " << endl;
            cout << endl;
            cin >> valoractualizado;


            list.update(valor, valoractualizado);
            cout << "Nodo actualizado. " << endl;
            cout << endl;

            break;

            case 5:
            cout << "5. Borrar un nodo." << endl;
            cout << "Ingresa el nodo a eliminar: " << endl;
            cout << endl;
            cin >> valor;

            list.remove(valor);
            cout << "Nodo eliminado. " << endl;
            cout << endl;

            break;

            case 0:
            cout << "0. Salir del programa." << endl;
            cout << endl;
            break;

            default:
            cout << "Comando no permitido." << endl;
            cout << endl;
        };

    } while (opcion_menu != 0);

    return 0;
};
