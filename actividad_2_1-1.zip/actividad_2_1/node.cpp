#include <iostream>
#include "node.h"

using namespace std;

Node::Node() {
    data = 0;
    prev = nullptr;
    next = nullptr;
};

Node::Node(int data, Node* prev, Node* next) {
    this->data = data;
    this->prev = prev;
    this->next = next;
};