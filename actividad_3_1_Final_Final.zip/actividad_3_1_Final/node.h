#ifndef NODE_H
#define NODE_H
#include <iostream>


using namespace std;

class Node {

    public:
    Node();
    Node(int data, Node* left, Node* right);

    public:
    int data;
    Node* left;
    Node* right;

};


#endif