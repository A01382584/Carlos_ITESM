#include <iostream>
#include "node.h"

using namespace std;


Node::Node(){

    left = nullptr;
    right = nullptr;
    data = 0;

};

Node::Node(int data, Node* left, Node* right){

    this->data = data;
    this->left = left;
    this->right = right;

};
