#ifndef BST_H
#define BST_H
#include "node.h"
#include <iostream>

using namespace std;

class BinaryT{

    public:
    BinaryT();

    //Pseudo CRUD
    Node* createINode(int data);
    void createNode(int data);
    Node* searchNode(int data);

    //ACT 3.1
    //Visits
    void visitBSTPre(Node *Nodito);
    void visitBSTIno(Node *Nodito);
    void visitBSTPost(Node *Nodito);
    void visitBSTLvl(Node *Nodito);
    void visitHeightlvl(Node *Nodito);

    //Print visits desde root
    void pvisitBSTPre();
    void pvisitBSTIno();
    void pvisitBSTPost();
    void pvisitBSTLvl();
    void pLevel(int nodo);
    
    void heightBST();
    void ancestorsBST(Node *Root, Node *Nodito, bool& status);
    Node* Ndint(int node);
    int levelSearch(Node *Nodito, Node *Rooti);

    public:
    Node *root = nullptr;

};

#endif