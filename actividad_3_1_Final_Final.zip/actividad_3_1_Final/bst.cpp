#include "bst.h"
#include <iostream>
#include <queue>

using namespace std;

BinaryT::BinaryT(){
    root = nullptr;
    int data = 0;
};

Node* BinaryT::createINode(int data){
    Node* INode = new Node;
    INode->data = data;
    INode->left = nullptr;
    INode->right = nullptr;
    return INode;
};

void BinaryT::createNode(int data) {
    
    Node* newNode = createINode(data);
    Node *temporary, *troot;

    if (root == nullptr){
        root = newNode;
    }

    else {

        temporary = root;
        while (temporary != nullptr){
            troot = temporary;
            if (data < temporary->data){
                temporary = temporary->left;
            }
            else{
                temporary = temporary->right;
            }
        }

        if (data < troot->data){
            troot->left = newNode;
        }
        else{
            troot->right = newNode;
        }

    }

};


Node* BinaryT::searchNode(int data){
    Node* temporary = root;
    Node* result;

    while (temporary != nullptr){
        result = temporary;
        if(data < temporary->data){
            temporary = temporary->left;      
        }

        else if (data > temporary->data){     
            temporary = temporary->right;
        }

        else{
            return result;
        }
    }

    if (temporary == nullptr){
        cout << "No existe en el BST." << endl;
    }

    return result;
};

void BinaryT::visitBSTPre(Node *Nodito){
    
    if(Nodito != nullptr){
        cout << Nodito->data << " ";
        visitBSTPre(Nodito->left);
        visitBSTPre(Nodito->right);
    }
};

void BinaryT::visitBSTIno(Node *Nodito){
    if(Nodito != nullptr){
        visitBSTIno(Nodito->left);
        cout << Nodito->data << " ";
        visitBSTIno(Nodito->right);
    }

};

void BinaryT::visitBSTPost(Node *Nodito){
    if(Nodito != nullptr){
        visitBSTPost(Nodito->left);
        visitBSTPost(Nodito->right);
        cout << Nodito->data << " ";
    }
};

void BinaryT::visitBSTLvl(Node *Nodito){

    int counter = 1;
    bool status = false;
    queue<Node*> levels;
    levels.push(Nodito);
    Node* current;
    
    if(Nodito != nullptr){

        while (!levels.empty()){
            int n = levels.size();
            status = false;
            cout << "----Lvl----" << counter << endl;

            for(int i = 0; i < n; i++){
                current = levels.front();
                levels.pop();
                cout << current->data << " ";

                if(current->left != nullptr){
                    levels.push(current->left);
                    status = true;
                }

                if(current->right != nullptr){
                    levels.push(current->right);
                    status = true;
                }
            }

            cout << endl;

            if (status == true){
                counter = counter+1;
            }
        };

    }

    else{
        cout << "No hay nada en el BST." << endl;
    };
};

void BinaryT::visitHeightlvl(Node *Nodito){

    int counter = 1;
    bool status = false;
    queue<Node*> levels;
    levels.push(Nodito);
    Node* current;

    while (!levels.empty()){
        int n = levels.size();
        status = false;

        for(int i = 0; i < n; i++){
            current = levels.front();
            levels.pop();

            if(current->left != nullptr){
                levels.push(current->left);
                status = true;
            }

            if(current->right != nullptr){
                levels.push(current->right);
                status = true;
            }
        }

        if (status == true){
            counter = counter+1;
        }
    };

    cout << "Levels: " << counter << endl;
};

int BinaryT::levelSearch(Node *Nodito, Node *Rooti){

    int counter = 1;
    bool status = false;
    queue<Node*> levels;
    levels.push(Rooti);
    Node* current;

    while (levels.empty() == false){
        int n = levels.size();
        status = false;

        for(int i = 0; i < n; i++){
            current = levels.front();
            Rooti = current;
            levels.pop();

            if (Nodito->data == Rooti->data){
                return counter;
            }

            if(current->left != nullptr){
                levels.push(current->left);
                status = true;
            }

            if(current->right != nullptr){
                levels.push(current->right);
                status = true;
            }
        }

        if (status == true){
            counter = counter+1;
        }
    };

    return counter;
};

void BinaryT::pLevel(int nodo){
    
    Node* Nodito = searchNode(nodo);
    int level = levelSearch(Nodito, root);
    cout << "Nodo en nivel: " << level << endl;

};

void BinaryT::heightBST(){
    visitHeightlvl(root);
    cout << endl;
};


void BinaryT::pvisitBSTPre(){
    visitBSTPre(root);
    cout << endl;
};

void BinaryT::pvisitBSTIno(){
    visitBSTIno(root);
    cout << endl;
};

void BinaryT::pvisitBSTPost(){
    visitBSTPost(root);
    cout << endl;
};

void BinaryT::pvisitBSTLvl(){
    visitBSTLvl(root);
    cout << endl;
};

void BinaryT::ancestorsBST(Node *Root, Node *Nodito, bool& status){

    if(Root == nullptr){
        return;
    }
    
    if(Root == Nodito){
        status = true;
        cout << Root->data << " ";
        return;
    }

    ancestorsBST(Root->left, Nodito, status);
    ancestorsBST(Root->right, Nodito, status);

    if(status){
        cout << Root->data << " ";
        return;
    }

};

Node* BinaryT::Ndint(int node){
    Node* Nodito = searchNode(node);
    return Nodito;
}