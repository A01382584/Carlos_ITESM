#include <iostream>
#include "node.h"
#include "bst.h"
#include <queue>
#include <random>
#include <vector>
#include <set>
#include <algorithm>

using namespace std;

int main(){

    int n = 20;
    int m;
    BinaryT registros;
    vector<int> check;
    set<int> check2;

    random_device rndd;
    mt19937 gen(rndd());
    uniform_int_distribution<> distr(1, 17);
    bool status = false;
    
    int opcion_menu;

    cout << endl;
    cout << "Act 3.1 - Operaciones avanzadas en un BST." << endl;
    cout << "Seleccione lo que desee hacer:" << endl;
    cout << "(Teclee el numero de la opcion en el Listado y presione enter)." << endl;

    do{

        cout << endl;
        cout << "1. Crear el BST Dummy." << endl;
        cout << "2. Agregar un nodo." << endl;
        cout << "3. Imprimir el BST (en las 4 rutas preestablecidas)." << endl;
        cout << "4. Consulta altura del BST." << endl;
        cout << "5. Consulta los ancestros de un nodo dentro del BST." << endl;
        cout << "6. Consulta el nivel del nodo dentro del BST." << endl;
        cout << "0. Salir del programa." << endl;
        cout << endl;

        cin >> opcion_menu;

        switch(opcion_menu){
            case 1:
            cout << "1. Crear el BST Dummy." << endl;

            for(int i = 0; i < n; i++){
                int num = distr(gen);
                check2.insert(num);
            }

            for(auto i : check2){
                check.push_back(i);
            }

            shuffle(check.begin(), check.end(), gen);

            for(int j : check){
                registros.createNode(j);
                cout << j << " ";
            }
            cout << endl;

            break;

            case 2:
            cout << "2. Agregar un nodo." << endl;
            cout << endl;

            cout << "Ingrese el nodo que quiere insertar: " << endl;
            cin >> m;
            cout << endl;

            registros.createNode(m);

            break;

            case 3:
            cout << "3. Imprimir el BST (en las 4 rutas preestablecidas)." << endl;
            cout << endl;

            cout << "Preorden: " << endl;
            registros.pvisitBSTPre();
            cout << endl;

            cout << "Inorden: " << endl;
            registros.pvisitBSTIno();
            cout << endl;

            cout << "Posorden: " << endl;
            registros.pvisitBSTPost();
            cout << endl;

            cout << "Nivel por nivel: " << endl;
            registros.pvisitBSTLvl();
            cout << endl;

            break;

            case 4:
            cout << "4. Consulta altura del BST." << endl;
            cout << endl;

            cout << "Altura: ";
            registros.heightBST();
            cout << endl;

            break;

            case 5:
            int nodoi;
            cout << "5. Consulta los ancestros de un nodo dentro del BST." << endl;
            cout << endl;

            cout << "Nodo: ";
            cin >> nodoi;

            registros.ancestorsBST(registros.root, registros.Ndint(nodoi), status);
            cout << endl;

            break;

            case 6:
            int nodo;
            cout << "6. Consulta el nivel del nodo dentro del BST." << endl;
            cout << endl;

            cout << "Nodo: ";
            cin >> nodo;
            registros.pLevel(nodo);
            cout << endl;

            break;

            case 0:
            cout << "0. Salir del programa." << endl;
            cout << endl;
            break;

            default:
            cout << "Comando no permitido." << endl;
            cout << endl;
        };

    } while (opcion_menu != 0);

    return 0;

};
